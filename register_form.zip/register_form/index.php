<!---
Welcome to the Sourcecodester.com
For more tutorials, kindly visit our website:

http://www.sourcecodester.com/
-->
<!DOCTYPE html>
<html>
<head>
<title>Register Form - j query Validation</title>
<script src="js/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="js/jquery.validate.min.js"></script>
<script>
        
		$().ready(function() {
        $("#register_form").validate({
            rules: {
                firstname: "required",
                lastname: "required",
                username: {
                    required: true,
                    minlength: 2
                },
                password: {
                    required: true,
                    minlength: 5
                },
                confirm_password: {
                    required: true,
                    minlength: 5,
                    equalTo: "#password"
                },
                email: {
                    required: true,
                    email: true
                },
                topic: {
                    required: "#newsletter:checked",
                    minlength: 2
                },
                agree: "required"
            },
            messages: {
                firstname: " <span style='color:red;'>*</span> Enter your firstname",
                lastname: " <span style='color:red;'>*</span> Enter your lastname",
                username: {
                    required: " <span style='color:red;'>*</span> Enter a username",
                    minlength: " <span style='color:red;'>*</span> Your username must consist of at least 2 characters"
                },
                password: {
                    required: " <span style='color:red;'>*</span> Provide a password",
                    minlength: " <span style='color:red;'>*</span> Your password must be at least 5 characters long"
                },
                confirm_password: {
                    required: " <span style='color:red;'>*</span> Confirm your password",
                    minlength: " <span style='color:red;'>*</span> Your password must be at least 5 characters long",
                    equalTo: " <span style='color:red;'>*</span> Enter the same password as above"
                },
                email: " <span style='color:red;'>*</span> Enter a valid email address",
                agree: " <span style='color:red;'>*</span> Agree to our terms"
            }
        });
		});
</script>
<style type="text/css">
body {
	margin:0;
	padding:0;
	font-family:"Calibri";
}

table {
	border:3px groove #CCC;
}

.btn_submit {
	font-size:20px;
	font-weight:bold;
	border-radius:5px;
}

.btn_cancel {
	font-size:20px;
	font-weight:bold;
	border-radius:5px;
}

input {
	font-size:18px;
	text-indent:4px;
}

label {
	color:#0000ff;
	font-size:20px;
}
</style>
</head>

<body>

<form id="register_form" method="post">
<table border="1" cellspacing="5" cellpadding="5">
	<tbody>
		<tr>
			<td>
				<label for="firstname">Firstname</label>
			</td>
			<td>
				<input id="firstname" name="firstname" placeholder="Firstname..." type="text" />
			</td>
		</tr>
		<tr>
			<td>
				<label for="lastname">Lastname</label>
			</td>
			<td>
				<input id="lastname" name="lastname" placeholder="Lastname..." type="text" />
			</td>
		</tr>
		<tr>
			<td>
				<label for="username">Username</label>
			</td>
			<td>
				<input id="username" name="username" placeholder="Username..." type="text" />
			</td>
		</tr>
		<tr>
			<td>
				<label for="password">Password</label>
			</td>
			<td>
				<input id="password" name="password" placeholder="Password..." type="text" />
			</td>
		</tr>
		<tr>
			<td>
				<label for="confirm_password">Confirm Password</label>
			</td>
			<td>
				<input id="confirm_password" placeholder="Confirm Password..." name="confirm_password" type="text" />
			</td>
		</tr>
		<tr>
			<td>
				<label for="email">Email</label>
			</td>
			<td>
				<input id="email" name="email" placeholder="Email..." type="text" />
			</td>
		</tr>
		<tr>
			<td>
				<label for="agree">I Agree To Terms</label>
			</td>
			<td>
				<input  type="checkbox" class="checkbox" id="agree" name="agree" />
			</td>
		</tr>
		<tr>
			<td colspan="2" align="center">
				<button class="btn_submit" type="submit">Submit</button>
                <button class="btn_cancel" type="reset">Cancel</button>
			</td>
		</tr>
	</tbody>
</table>
</form>

<a href="http://www.sourcecodester.com">
	<h3>
		Sourcecodester
	</h3>
</a>

</body>
</html>
