<?php
include("dbcon.php");
$search = strtolower($_GET["q"]);
if (!$search) return;
$sql = "select DISTINCT fullname as fullname from users where fullname LIKE '%$search%' limit 5";
$query = mysql_query($sql);
while($row = mysql_fetch_array($query)) {
	$name = $row['fullname'];
	echo "$name\n";
}
?>