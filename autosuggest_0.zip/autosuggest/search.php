<!DOCTYPE HTML>
<html>
<head>

<title>Search Autosuggest</title>
<script type="text/javascript" src="js/jquery.js"></script>
<script type='text/javascript' src='js/jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="css/style.css" />

<script type="text/javascript">
$().ready(function() {
	$("#name").autocomplete("getresult.php", {
		width: 218,
		matchContains: true,
		selectFirst: false
	});
});
</script>

<?php
include("dbcon.php");
?>
</head>
<body>
<h2 id="banner">Search Autosuggest</h1>
<div id="content">
	<form autocomplete="off">
			<input type="search" name="fullname" id="name" style="width:220px;padding:10px;" placeholder="Search here..." />
		</form>
</div><br/>
</body>
</html>
