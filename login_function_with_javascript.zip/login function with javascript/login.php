<?php 
include('dbcon.php');

session_start();
$username = $_POST['username'];
$password = $_POST['password'];

$query = $conn->query("Select * from user where username = '$username' and password ='$password' ");
$count = $query->rowcount();
$row = $query->fetch();


		if ($count > 0){
		
		$_SESSION['id']=$row['user_id'];
		
		echo 'true';
		
		
		 }else{ 
		echo 'false';
		}	

?>